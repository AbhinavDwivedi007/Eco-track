const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { getDbStatus } = require('../config/db');
const { getMemoryUser } = require('../controllers/userController');

const JWT_SECRET = process.env.JWT_SECRET || 'ecotrack_college_jwt_secret_key_2026';

/**
 * Authentication middleware to verify JWT token and attach user to req.user
 */
async function protect(req, res, next) {
  let token = null;

  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Not authorized - No authentication token provided'
    });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);

    if (getDbStatus().connected) {
      const user = await User.findById(decoded.id).select('-password');
      if (!user) {
        return res.status(401).json({ success: false, message: 'User not found for this token' });
      }
      req.user = user;
    } else {
      // Memory fallback for demo mode without local MongoDB
      req.user = {
        _id: decoded.id || 'default_user',
        name: decoded.name || 'Eco Warrior',
        email: decoded.email || 'user@ecotrack.local'
      };
    }

    next();
  } catch (error) {
    return res.status(401).json({
      success: false,
      message: 'Not authorized - Invalid or expired token'
    });
  }
}

/**
 * Optional authentication middleware: if token present, attach user; otherwise proceed as guest
 */
async function optionalAuth(req, res, next) {
  let token = null;
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (token) {
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      if (getDbStatus().connected) {
        req.user = await User.findById(decoded.id).select('-password');
      } else {
        req.user = {
          _id: decoded.id || 'default_user',
          name: decoded.name || 'Eco Warrior',
          email: decoded.email || 'user@ecotrack.local'
        };
      }
    } catch (err) {
      // Token invalid, proceed as guest
      req.user = null;
    }
  } else {
    req.user = null;
  }

  next();
}

module.exports = {
  protect,
  optionalAuth,
  JWT_SECRET
};
