/**
 * Input validation middleware for EcoTrack APIs
 */

function validateCarbonCalculation(req, res, next) {
  const { distanceKm, electricityKwh, monthlyLpgKg, fuelLitres } = req.body;

  const errors = [];

  if (distanceKm !== undefined && (isNaN(distanceKm) || Number(distanceKm) < 0)) {
    errors.push('distanceKm must be a non-negative number');
  }

  if (electricityKwh !== undefined && (isNaN(electricityKwh) || Number(electricityKwh) < 0)) {
    errors.push('electricityKwh must be a non-negative number');
  }

  if (monthlyLpgKg !== undefined && (isNaN(monthlyLpgKg) || Number(monthlyLpgKg) < 0)) {
    errors.push('monthlyLpgKg must be a non-negative number');
  }

  if (fuelLitres !== undefined && (isNaN(fuelLitres) || Number(fuelLitres) < 0)) {
    errors.push('fuelLitres must be a non-negative number');
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors
    });
  }

  next();
}

function validateCheckIn(req, res, next) {
  const { transport, energy, food, waste } = req.body;
  const errors = [];

  if (!transport) errors.push('transport is required');
  if (!energy) errors.push('energy level is required');
  if (!food) errors.push('food choice is required');
  if (!waste) errors.push('waste level is required');

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors
    });
  }

  next();
}

module.exports = {
  validateCarbonCalculation,
  validateCheckIn
};
