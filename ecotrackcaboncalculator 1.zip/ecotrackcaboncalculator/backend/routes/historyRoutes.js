const express = require('express');
const router = express.Router();
const historyController = require('../controllers/historyController');
const { optionalAuth } = require('../middleware/auth');

// POST /api/carbon/history
router.post('/', optionalAuth, historyController.saveHistory);

// GET /api/carbon/history
router.get('/', optionalAuth, historyController.getHistory);

// GET /api/carbon/history/summary
router.get('/summary', optionalAuth, historyController.getSummary);

// GET /api/carbon/history/:id
router.get('/:id', optionalAuth, historyController.getHistoryById);

// DELETE /api/carbon/history/:id
router.delete('/:id', optionalAuth, historyController.deleteHistory);

module.exports = router;
