const express = require('express');
const router = express.Router();
const carbonController = require('../controllers/carbonController');
const { validateCarbonCalculation } = require('../middleware/validate');
const { optionalAuth } = require('../middleware/auth');

// POST /api/carbon/calculate
router.post('/calculate', optionalAuth, validateCarbonCalculation, carbonController.calculate);

// POST /api/carbon/simulate
router.post('/simulate', carbonController.simulate);

module.exports = router;
