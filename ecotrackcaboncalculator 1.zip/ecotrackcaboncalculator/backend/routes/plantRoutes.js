const express = require('express');
const router = express.Router();
const plantController = require('../controllers/plantController');
const { optionalAuth } = require('../middleware/auth');

// GET /api/plants - list plants for current user / guest
router.get('/', optionalAuth, plantController.getPlants);

// POST /api/plants - add a new plant with absorption estimate
router.post('/', optionalAuth, plantController.addPlant);

// GET /api/plants/summary - total annual absorption summary
router.get('/summary', optionalAuth, plantController.getPlantSummary);

// GET /api/plants/species - curated botanical catalog
router.get('/species', plantController.getSpeciesCatalog);

// POST /api/plants/identify - AI visual species identification
router.post('/identify', plantController.identifySpecies);

// DELETE /api/plants/:id - delete a plant record
router.delete('/:id', optionalAuth, plantController.deletePlant);

module.exports = router;
