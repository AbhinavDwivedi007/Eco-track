const mongoose = require('mongoose');

let isConnected = false;

const connectDB = async () => {
  const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/ecotrack';

  try {
    mongoose.set('strictQuery', false);
    const conn = await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 3000, // Quick timeout to avoid hanging if offline
    });

    isConnected = true;
    console.log(`[MongoDB] Connected successfully to host: ${conn.connection.host}, database: ${conn.connection.name}`);
    return conn;
  } catch (error) {
    isConnected = false;
    console.warn(`[MongoDB Warning] Could not establish connection to ${uri}`);
    console.warn(`[MongoDB Notice] Message: ${error.message}`);
    console.warn(`[MongoDB Notice] EcoTrack will run with resilient fallback mode. To persist data in MongoDB, ensure mongod is running locally or specify MONGODB_URI in backend/.env`);
    return null;
  }
};

const getDbStatus = () => ({
  connected: isConnected,
  readyState: mongoose.connection.readyState,
  host: mongoose.connection.host || null,
  name: mongoose.connection.name || null
});

module.exports = {
  connectDB,
  getDbStatus
};
