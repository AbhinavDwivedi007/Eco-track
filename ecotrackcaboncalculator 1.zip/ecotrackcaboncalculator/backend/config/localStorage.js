const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const STORE_FILE = path.join(DATA_DIR, 'local_store.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  } catch (err) {
    console.error('[Storage] Could not create data directory:', err.message);
  }
}

/**
 * Load persisted data from disk if present
 */
function loadPersistedData() {
  try {
    if (fs.existsSync(STORE_FILE)) {
      const raw = fs.readFileSync(STORE_FILE, 'utf-8');
      const data = JSON.parse(raw);
      return {
        users: Array.isArray(data.users) ? data.users : [],
        history: Array.isArray(data.history) ? data.history : [],
        plants: Array.isArray(data.plants) ? data.plants : []
      };
    }
  } catch (err) {
    console.error('[Storage] Error loading local_store.json:', err.message);
  }
  return { users: [], history: [], plants: [] };
}

/**
 * Persist users map, history array, and plants array to disk
 */
function savePersistedData(usersMap, historyArray, plantsArray) {
  try {
    const existing = loadPersistedData();
    const usersList = [];
    if (usersMap instanceof Map) {
      for (const [_, user] of usersMap) {
        usersList.push(user);
      }
    } else if (Array.isArray(usersMap)) {
      usersList.push(...usersMap);
    } else if (existing.users) {
      usersList.push(...existing.users);
    }

    const payload = {
      version: '1.0',
      savedAt: new Date().toISOString(),
      users: usersList,
      history: Array.isArray(historyArray) ? historyArray : (existing.history || []),
      plants: Array.isArray(plantsArray) ? plantsArray : (existing.plants || [])
    };

    fs.writeFileSync(STORE_FILE, JSON.stringify(payload, null, 2), 'utf-8');
  } catch (err) {
    console.error('[Storage] Error saving local_store.json:', err.message);
  }
}

module.exports = {
  loadPersistedData,
  savePersistedData
};
