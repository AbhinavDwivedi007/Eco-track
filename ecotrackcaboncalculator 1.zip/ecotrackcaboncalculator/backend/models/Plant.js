const mongoose = require('mongoose');

const PlantSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
    index: true
  },
  name: {
    type: String,
    required: [true, 'Plant nickname/name is required'],
    trim: true,
    maxlength: 100
  },
  species: {
    type: String,
    required: [true, 'Plant species is required'],
    trim: true,
    maxlength: 120
  },
  scientificName: {
    type: String,
    trim: true,
    default: ''
  },
  plantType: {
    type: String,
    enum: ['indoor', 'outdoor_tree', 'shrub', 'succulent', 'herb_flowering', 'other'],
    default: 'indoor'
  },
  size: {
    type: String,
    enum: ['small', 'medium', 'large', 'mature'],
    default: 'medium'
  },
  plantingDate: {
    type: Date,
    default: Date.now
  },
  approxAgeMonths: {
    type: Number,
    min: 0,
    default: 6
  },
  photoUrl: {
    type: String,
    default: ''
  },
  estimatedCo2PerYear: {
    type: Number,
    required: true,
    min: 0
  },
  confidence: {
    type: Number,
    min: 0,
    max: 100,
    default: 90
  },
  methodology: {
    type: String,
    default: 'Estimated based on average annual biomass accumulation rates for species foliage and size (kg CO2/year).'
  },
  notes: {
    type: String,
    trim: true,
    maxlength: 500,
    default: ''
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Plant', PlantSchema);
