const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const RewardMilestones = [
  { id: 'starter', name: 'Eco Starter', daysRequired: 7, icon: 'fa-seedling', description: 'Complete 7 consecutive days of carbon tracking.' },
  { id: 'saver', name: 'Eco Saver', daysRequired: 14, icon: 'fa-shield-halved', description: 'Maintain a 14-day streak of mindful eco tracking.' },
  { id: 'champion', name: 'Green Champion', daysRequired: 30, icon: 'fa-trophy', description: 'Reach 30 consecutive days of environmental tracking.' }
];

const UserSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Please provide your name'],
    trim: true,
    default: 'Eco Warrior'
  },
  email: {
    type: String,
    required: [true, 'Please provide your email'],
    unique: true,
    trim: true,
    lowercase: true
  },
  password: {
    type: String,
    required: [true, 'Please provide a password'],
    minlength: 6,
    select: false // Do not return password by default
  },
  avatar: {
    type: String,
    default: '🌱'
  },
  joinedDate: {
    type: String,
    default: () => new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
  },
  metrics: {
    todayFootprint: {
      type: Number,
      default: 0
    },
    previousFootprint: {
      type: Number,
      default: 0
    },
    ecoScore: {
      type: Number,
      default: 75
    },
    ecoGrade: {
      type: String,
      default: 'B'
    },
    highestCategory: {
      type: String,
      default: 'transport'
    },
    scoreBreakdown: {
      transport: { type: Number, default: 0 },
      energy: { type: Number, default: 0 },
      food: { type: Number, default: 0 },
      waste: { type: Number, default: 0 }
    },
    totalCalculations: {
      type: Number,
      default: 0
    }
  },
  streak: {
    current: {
      type: Number,
      default: 0
    },
    best: {
      type: Number,
      default: 0
    },
    lastTrackedDate: {
      type: String,
      default: null
    },
    trackingDates: {
      type: [String],
      default: []
    }
  },
  rewards: {
    type: [
      {
        id: { type: String, required: true },
        name: { type: String, required: true },
        daysRequired: { type: Number, required: true },
        icon: { type: String, default: 'fa-award' },
        description: { type: String },
        unlocked: { type: Boolean, default: false },
        unlockedAt: { type: Date, default: null }
      }
    ],
    default: () => RewardMilestones.map(m => ({ ...m, unlocked: false, unlockedAt: null }))
  }
}, {
  timestamps: true
});

// Hash password prior to saving
UserSchema.pre('save', async function (next) {
  if (!this.isModified('password')) {
    return next();
  }
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// Compare input password with hashed password
UserSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

module.exports = mongoose.model('User', UserSchema);
module.exports.RewardMilestones = RewardMilestones;
