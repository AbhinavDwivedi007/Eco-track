const mongoose = require('mongoose');

const DailyCheckInSchema = new mongoose.Schema({
  userId: {
    type: String,
    default: 'default_user',
    index: true
  },
  date: {
    type: String,
    required: true,
    default: () => new Date().toISOString().split('T')[0]
  },
  transport: {
    type: String,
    required: true,
    enum: ['Car', 'Bike', 'Bus', 'Metro', 'Walking'],
    default: 'Metro'
  },
  energy: {
    type: String,
    required: true,
    enum: ['Low', 'Medium', 'High'],
    default: 'Low'
  },
  food: {
    type: String,
    required: true,
    enum: ['Vegetarian', 'Mixed', 'Non-vegetarian'],
    default: 'Vegetarian'
  },
  waste: {
    type: String,
    required: true,
    enum: ['Low', 'Medium', 'High'],
    default: 'Low'
  },
  footprint: {
    type: Number,
    required: true
  },
  score: {
    type: Number,
    required: true
  },
  pointsEarned: {
    type: Number,
    default: 5
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('DailyCheckIn', DailyCheckInSchema);
