const mongoose = require('mongoose');

const CarbonCalculationSchema = new mongoose.Schema({
  userId: {
    type: String,
    default: 'default_user',
    index: true
  },
  inputs: {
    vehicleType: { type: String, default: 'petrol_car' },
    distanceKm: { type: Number, default: 0 },
    fuelType: { type: String, default: 'petrol_litre' },
    fuelLitres: { type: Number, default: 0 },
    carpooling: { type: Boolean, default: false },
    electricityKwh: { type: Number, default: 0 },
    renewableEnergy: { type: Boolean, default: false },
    monthlyLpgKg: { type: Number, default: 0 },
    lpgCylindersPerMonth: { type: Number, default: 0 },
    naturalGasM3: { type: Number, default: 0 },
    dietType: { type: String, default: 'mixed' },
    wasteBags: { type: Number, default: 1 },
    recycling: { type: String, default: 'partial' },
    otherKg: { type: Number, default: 0 }
  },
  results: {
    totalFootprintKg: { type: Number, required: true },
    totalAnnualFootprintKg: { type: Number },
    breakdown: {
      transport: { type: Number, default: 0 },
      electricity: { type: Number, default: 0 },
      food: { type: Number, default: 0 },
      waste: { type: Number, default: 0 },
      lpgFuel: { type: Number, default: 0 },
      other: { type: Number, default: 0 }
    },
    ecoScore: { type: Number, default: 75 },
    ecoGrade: { type: String, default: 'B' },
    ecoStatus: { type: String, default: 'Eco-Conscious' },
    highestContributor: {
      name: String,
      key: String,
      value: Number,
      percentage: Number,
      icon: String
    },
    equivalencies: {
      treesNeededPerYear: Number,
      carKmEquivalent: Number
    }
  },
  source: {
    type: String,
    enum: ['calculator', 'check-in', 'api'],
    default: 'calculator'
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('CarbonCalculation', CarbonCalculationSchema);
