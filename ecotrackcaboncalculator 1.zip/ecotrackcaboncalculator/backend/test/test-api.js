process.env.NODE_ENV = 'test';
process.env.PORT = 5098;

const http = require('http');
const app = require('../server');

let server;
const BASE_URL = 'http://localhost:5098';

async function runTests() {
  console.log('🧪 Starting EcoTrack Comprehensive API Test Suite...\n');

  server = app.listen(5098);

  let passed = 0;
  let failed = 0;

  async function assertTest(name, fn) {
    try {
      await fn();
      console.log(`✅ [PASS] ${name}`);
      passed++;
    } catch (err) {
      console.error(`❌ [FAIL] ${name}`);
      console.error(`   ${err.message}`);
      failed++;
    }
  }

  // 1. Health check
  await assertTest('GET /api/health returns healthy status', async () => {
    const res = await fetch(`${BASE_URL}/api/health`);
    const data = await res.json();
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (data.status !== 'healthy') throw new Error(`Unexpected status: ${data.status}`);
  });

  // 2. Authentication: Register
  let user1Token = null;
  const user1Email = `student_${Date.now()}@college.edu`;
  await assertTest('POST /api/auth/register creates user & returns JWT', async () => {
    const res = await fetch(`${BASE_URL}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'College Presenter',
        email: user1Email,
        password: 'password123'
      })
    });
    const data = await res.json();
    if (res.status !== 201) throw new Error(`Status ${res.status}: ${data.message}`);
    if (!data.token) throw new Error('Token not returned');
    if (data.user.name !== 'College Presenter') throw new Error('Name mismatch');
    user1Token = data.token;
  });

  // 3. Authentication: Login
  await assertTest('POST /api/auth/login verifies credentials', async () => {
    const res = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: user1Email,
        password: 'password123'
      })
    });
    const data = await res.json();
    if (res.status !== 200) throw new Error(`Status ${res.status}: ${data.message}`);
    if (!data.token) throw new Error('Token not returned on login');
  });

  // 4. Authentication: Get Profile
  await assertTest('GET /api/auth/me returns authenticated user profile', async () => {
    const res = await fetch(`${BASE_URL}/api/auth/me`, {
      headers: { 'Authorization': `Bearer ${user1Token}` }
    });
    const data = await res.json();
    if (res.status !== 200) throw new Error(`Status ${res.status}: ${data.message}`);
    if (data.user.email !== user1Email) throw new Error('User email mismatch');
    if (!Array.isArray(data.user.rewards)) throw new Error('Rewards array missing');
  });

  // 5. Carbon Calculation & Streak Progress
  await assertTest('POST /api/carbon/calculate calculates footprint and increments streak', async () => {
    const payload = {
      vehicleType: 'petrol_car',
      distanceKm: 20,
      carpooling: false,
      electricityKwh: 120,
      renewableEnergy: false,
      dietType: 'mixed',
      wasteBags: 1,
      recycling: 'partial',
      saveToHistory: true
    };

    const res = await fetch(`${BASE_URL}/api/carbon/calculate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${user1Token}`
      },
      body: JSON.stringify(payload)
    });

    const data = await res.json();
    if (res.status !== 200) throw new Error(`Status ${res.status}: ${data.message}`);
    if (typeof data.data.totalFootprintKg !== 'number') throw new Error('No totalFootprintKg');
    if (!data.data.breakdown.transport) throw new Error('Missing transport breakdown');
    if (data.data.user) {
      if (data.data.user.streak.current < 1) throw new Error('Streak not incremented');
      if (data.data.user.streak.trackingDates.length < 1) throw new Error('Tracking dates empty');
    }
  });

  // 6. Habit Simulator
  await assertTest('POST /api/carbon/simulate returns habit comparison', async () => {
    const res = await fetch(`${BASE_URL}/api/carbon/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ currentMode: 'car', newMode: 'metro', dailyKm: 25 })
    });
    const data = await res.json();
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (data.data.diffKg <= 0) throw new Error('Expected positive emission savings');
  });

  // 7. User Data Isolation Verification
  const user2Email = `student2_${Date.now()}@college.edu`;
  let user2Token = null;
  await assertTest('Register second user and verify data isolation', async () => {
    // Register user 2
    const resReg = await fetch(`${BASE_URL}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Second Student',
        email: user2Email,
        password: 'password123'
      })
    });
    const dataReg = await resReg.json();
    user2Token = dataReg.token;

    // Check history for user 2 -> must be 0
    const resHist = await fetch(`${BASE_URL}/api/carbon/history`, {
      headers: { 'Authorization': `Bearer ${user2Token}` }
    });
    const dataHist = await resHist.json();
    if (dataHist.data.calculations.length !== 0) {
      throw new Error(`Data leakage! User 2 sees ${dataHist.data.calculations.length} calculations`);
    }

    // Check history for user 1 -> must have the calculation we did earlier
    const resHist1 = await fetch(`${BASE_URL}/api/carbon/history`, {
      headers: { 'Authorization': `Bearer ${user1Token}` }
    });
    const dataHist1 = await resHist1.json();
    if (dataHist1.data.calculations.length < 1) {
      throw new Error('User 1 missing their own calculations');
    }
  });

  // 8. Plant Species Catalog
  await assertTest('GET /api/plants/species returns curated botanical list', async () => {
    const res = await fetch(`${BASE_URL}/api/plants/species`);
    const data = await res.json();
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (!Array.isArray(data.data) || data.data.length < 5) throw new Error('Catalog empty or too small');
  });

  // 9. Plant Species Identification
  await assertTest('POST /api/plants/identify provides botanical scan suggestions', async () => {
    const res = await fetch(`${BASE_URL}/api/plants/identify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ hint: 'snake' })
    });
    const data = await res.json();
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (!data.analysis || !data.analysis.suggestions || data.analysis.suggestions.length === 0) {
      throw new Error('No suggestions returned');
    }
    if (!data.analysis.suggestions[0].name.toLowerCase().includes('snake')) {
      throw new Error('Expected snake plant suggestion');
    }
  });

  // 10. Add Plant with Scientific Absorption Calculation
  let createdPlantId = null;
  await assertTest('POST /api/plants creates plant record with estimated CO2 absorption', async () => {
    const res = await fetch(`${BASE_URL}/api/plants`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${user1Token}`
      },
      body: JSON.stringify({
        name: 'Desk Snake Plant',
        species: 'Snake Plant / Mother-in-Law\'s Tongue',
        size: 'medium',
        approxAgeMonths: 12,
        notes: 'Sitting on study table'
      })
    });
    const data = await res.json();
    if (res.status !== 201) throw new Error(`Status ${res.status}: ${data.message}`);
    if (!data.data._id) throw new Error('Plant ID missing');
    if (!data.data.estimatedCo2PerYear || data.data.estimatedCo2PerYear <= 0) {
      throw new Error('Valid estimated CO2 absorption not calculated');
    }
    createdPlantId = data.data._id;
  });

  // 11. Plant Summary & Combined Annual Sequestration
  await assertTest('GET /api/plants/summary computes total annual absorption without double-counting', async () => {
    const res = await fetch(`${BASE_URL}/api/plants/summary`, {
      headers: { 'Authorization': `Bearer ${user1Token}` }
    });
    const data = await res.json();
    if (res.status !== 200) throw new Error(`Status ${res.status}`);
    if (data.data.totalPlants < 1) throw new Error('Expected at least 1 saved plant');
    if (data.data.totalAbsorptionKgPerYear <= 0) throw new Error('Expected positive annual absorption');
  });

  // 12. Plant Isolation between Users
  await assertTest('Verify plant records are strictly isolated per user', async () => {
    // User 2 should have 0 plants
    const res2 = await fetch(`${BASE_URL}/api/plants`, {
      headers: { 'Authorization': `Bearer ${user2Token}` }
    });
    const data2 = await res2.json();
    if (data2.data.length !== 0) {
      throw new Error(`Data leakage! User 2 sees ${data2.data.length} plants`);
    }

    // User 1 should see the plant
    const res1 = await fetch(`${BASE_URL}/api/plants`, {
      headers: { 'Authorization': `Bearer ${user1Token}` }
    });
    const data1 = await res1.json();
    if (data1.data.length !== 1 || data1.data[0]._id !== createdPlantId) {
      throw new Error('User 1 cannot access their own plant record');
    }
  });

  // 13. Plant Delete
  await assertTest('DELETE /api/plants/:id removes plant and user cannot delete other users plant', async () => {
    // User 2 attempts to delete User 1's plant -> must fail (403 or not found)
    const resForbidden = await fetch(`${BASE_URL}/api/plants/${createdPlantId}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${user2Token}` }
    });
    if (resForbidden.status !== 403 && resForbidden.status !== 404) {
      throw new Error(`Expected forbidden/404, got status ${resForbidden.status}`);
    }

    // User 1 deletes their plant
    const resDelete = await fetch(`${BASE_URL}/api/plants/${createdPlantId}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${user1Token}` }
    });
    const dataDelete = await resDelete.json();
    if (resDelete.status !== 200 || !dataDelete.success) {
      throw new Error(`Delete failed: ${dataDelete.message}`);
    }
  });

  console.log(`\n================================`);
  console.log(`🏁 Test Results: ${passed} passed, ${failed} failed`);
  console.log(`================================`);

  server.close(() => {
    process.exit(failed > 0 ? 1 : 0);
  });
}

runTests();
