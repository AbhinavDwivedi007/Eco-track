/**
 * EcoTrack - Carbon Footprint Calculation Engine
 * Pure, isolated, modular business logic for environmental calculations.
 */

// Vehicle emission factors (kg CO2 per passenger km)
const VEHICLE_FACTORS = {
  petrol_car: 0.192,
  diesel_car: 0.171,
  hybrid_car: 0.109,
  electric_car: 0.045,
  motorbike: 0.103,
  bus: 0.075,
  metro: 0.038,
  bicycle: 0.0,
  walking: 0.0
};

// Fuel emission factors (kg CO2 per unit)
const FUEL_FACTORS = {
  petrol_litre: 2.31,
  diesel_litre: 2.68,
  cng_kg: 2.75,
  lpg_kg: 2.98,
  natural_gas_m3: 1.90,
  electricity_kwh: 0.475
};

// Daily food footprint (kg CO2 per person per day)
const DIET_FACTORS = {
  meat_heavy: 7.2,
  mixed: 4.8,
  pescatarian: 3.8,
  vegetarian: 2.9,
  vegan: 2.1
};

// Waste factor (kg CO2 per standard household bag)
const WASTE_PER_BAG = 1.2;

const RECYCLING_FACTORS = {
  strict: 0.4,
  partial: 0.75,
  none: 1.0
};

/**
 * Calculate comprehensive carbon footprint from user lifestyle data
 * @param {Object} input
 * @returns {Object} detailed footprint, breakdowns, score, recommendations
 */
function calculateFootprint(input = {}) {
  // 1. Transportation
  const vehicleType = (input.vehicleType || 'petrol_car').toLowerCase();
  const distanceKm = Math.max(0, parseFloat(input.distanceKm) || 0);
  const carpooling = Boolean(input.carpooling);
  const carpoolDivisor = carpooling ? 2 : 1;

  let transportKg = 0;
  // If direct fuel usage was provided
  if (input.fuelLitres && parseFloat(input.fuelLitres) > 0) {
    const fuelType = (input.fuelType || 'petrol_litre').toLowerCase();
    const fuelFactor = FUEL_FACTORS[fuelType] || FUEL_FACTORS.petrol_litre;
    transportKg = (parseFloat(input.fuelLitres) * fuelFactor) / carpoolDivisor;
  } else {
    const vFactor = VEHICLE_FACTORS[vehicleType] !== undefined ? VEHICLE_FACTORS[vehicleType] : VEHICLE_FACTORS.petrol_car;
    transportKg = (distanceKm * vFactor) / carpoolDivisor;
  }
  transportKg = Number(transportKg.toFixed(2));

  // 2. Electricity
  const monthlyKwh = Math.max(0, parseFloat(input.electricityKwh) || 0);
  const renewableEnergy = Boolean(input.renewableEnergy);
  const renewableMultiplier = renewableEnergy ? 0.20 : 1.0; // 80% discount for solar/green tariff
  const dailyKwh = monthlyKwh / 30;
  const electricityKg = Number((dailyKwh * FUEL_FACTORS.electricity_kwh * renewableMultiplier).toFixed(2));

  // 3. LPG / Cooking Fuel / Natural Gas (optional extra activities)
  let lpgFuelKg = 0;
  if (input.monthlyLpgKg && parseFloat(input.monthlyLpgKg) > 0) {
    lpgFuelKg += (parseFloat(input.monthlyLpgKg) / 30) * FUEL_FACTORS.lpg_kg;
  } else if (input.lpgCylindersPerMonth && parseFloat(input.lpgCylindersPerMonth) > 0) {
    // 1 standard domestic cylinder ~ 14.2 kg
    const kgPerMonth = parseFloat(input.lpgCylindersPerMonth) * 14.2;
    lpgFuelKg += (kgPerMonth / 30) * FUEL_FACTORS.lpg_kg;
  }
  if (input.naturalGasM3 && parseFloat(input.naturalGasM3) > 0) {
    lpgFuelKg += (parseFloat(input.naturalGasM3) / 30) * FUEL_FACTORS.natural_gas_m3;
  }
  lpgFuelKg = Number(lpgFuelKg.toFixed(2));

  // 4. Food & Lifestyle
  const dietType = (input.dietType || 'mixed').toLowerCase();
  const foodBaseKg = DIET_FACTORS[dietType] !== undefined ? DIET_FACTORS[dietType] : DIET_FACTORS.mixed;
  const foodKg = Number(foodBaseKg.toFixed(2));

  // 5. Waste & Packaging
  const wasteBags = Math.max(0, parseFloat(input.wasteBags) || 1.0);
  const recycling = (input.recycling || 'partial').toLowerCase();
  const recyclingDiscount = RECYCLING_FACTORS[recycling] !== undefined ? RECYCLING_FACTORS[recycling] : RECYCLING_FACTORS.partial;
  const wasteKg = Number((wasteBags * WASTE_PER_BAG * recyclingDiscount).toFixed(2));

  // 6. Other relevant activities (flight, goods, shipping if provided)
  const otherKg = Math.max(0, parseFloat(input.otherKg) || 0);

  // Total daily emissions
  const totalDailyKg = Number((transportKg + electricityKg + lpgFuelKg + foodKg + wasteKg + otherKg).toFixed(2));
  const totalAnnualKg = Number((totalDailyKg * 365).toFixed(1));

  // Eco Score Computation (0 - 100)
  // Global ideal daily target is around 3.5 - 5.0 kg CO2
  // Baseline formula: 100 - (totalDailyKg * 4.0), clamped between 35 and 99
  const ecoScore = Math.max(35, Math.min(99, Math.round(100 - (totalDailyKg * 4.0))));

  let ecoGrade = 'B';
  let ecoStatus = 'Moderate Footprint';
  if (ecoScore >= 85) {
    ecoGrade = 'A+';
    ecoStatus = 'Eco Champion';
  } else if (ecoScore >= 75) {
    ecoGrade = 'A-';
    ecoStatus = 'Green Guardian';
  } else if (ecoScore >= 60) {
    ecoGrade = 'B';
    ecoStatus = 'Eco-Conscious';
  } else if (ecoScore >= 45) {
    ecoGrade = 'C';
    ecoStatus = 'Room for Improvement';
  } else {
    ecoGrade = 'D';
    ecoStatus = 'High Impact';
  }

  // Breakdown array for sorting highest contributor
  const breakdownList = [
    { name: 'Transportation', key: 'transport', value: transportKg, icon: 'fa-car' },
    { name: 'Electricity', key: 'electricity', value: electricityKg, icon: 'fa-bolt' },
    { name: 'Food & Diet', key: 'food', value: foodKg, icon: 'fa-utensils' },
    { name: 'Waste & Packaging', key: 'waste', value: wasteKg, icon: 'fa-trash-can' }
  ];

  if (lpgFuelKg > 0) {
    breakdownList.push({ name: 'Cooking LPG / Gas', key: 'lpgFuel', value: lpgFuelKg, icon: 'fa-fire-burner' });
  }
  if (otherKg > 0) {
    breakdownList.push({ name: 'Other Activities', key: 'other', value: otherKg, icon: 'fa-boxes-packing' });
  }

  breakdownList.sort((a, b) => b.value - a.value);
  const highest = breakdownList[0] || { name: 'Transportation', key: 'transport', value: transportKg, icon: 'fa-car' };
  const safeTotal = totalDailyKg > 0 ? totalDailyKg : 1;
  const highestPercent = Math.round((highest.value / safeTotal) * 100);

  // Offset Trees (1 mature tree absorbs ~21 kg CO2/year)
  const treesNeededAnnual = Math.max(1, Math.round(totalAnnualKg / 21));

  // Dynamic Personalized Suggestions based on highest contributors
  const suggestions = generateSuggestions(highest.key, {
    vehicleType,
    renewableEnergy,
    dietType,
    recycling
  });

  return {
    totalFootprintKg: totalDailyKg,
    totalAnnualFootprintKg: totalAnnualKg,
    breakdown: {
      transport: transportKg,
      electricity: electricityKg,
      food: foodKg,
      waste: wasteKg,
      lpgFuel: lpgFuelKg,
      other: otherKg
    },
    ecoScore,
    ecoGrade,
    ecoStatus,
    highestContributor: {
      name: highest.name,
      key: highest.key,
      value: highest.value,
      percentage: highestPercent,
      icon: highest.icon
    },
    equivalencies: {
      treesNeededPerYear: treesNeededAnnual,
      carKmEquivalent: Math.round(totalDailyKg / 0.192)
    },
    suggestions
  };
}

/**
 * Generate actionable suggestions based on largest emission sector
 */
function generateSuggestions(highestKey, context) {
  const tips = [];

  if (highestKey === 'transport') {
    tips.push({
      title: 'Shift to Public Transit or Metro',
      action: 'Replace 2 solo car commutes weekly with Metro or bus to reduce transport emissions by up to 60%.',
      impact: 'High'
    });
    tips.push({
      title: 'Active Mobility for Short Trips',
      action: 'Walk or cycle for trips under 3 km instead of using a car or scooter.',
      impact: 'Medium'
    });
  } else if (highestKey === 'electricity') {
    tips.push({
      title: 'Eliminate Standby Power',
      action: 'Unplug idle electronics, monitors, and chargers overnight to save up to 10% on monthly electric draw.',
      impact: 'Medium'
    });
    if (!context.renewableEnergy) {
      tips.push({
        title: 'Switch to Green Energy / Rooftop Solar',
        action: 'Look into community solar programs or clean energy provider tariffs to reduce electricity CO2 by 80%.',
        impact: 'High'
      });
    }
  } else if (highestKey === 'food') {
    tips.push({
      title: 'Adopt Meatless Monday / Plant-Rich Meals',
      action: 'Substituting red meat with lentils, beans, or plant proteins even 2 days a week cuts food emissions in half.',
      impact: 'High'
    });
    tips.push({
      title: 'Minimize Food Waste',
      action: 'Plan weekly meals in advance to avoid food rotting in the refrigerator.',
      impact: 'Medium'
    });
  } else {
    tips.push({
      title: 'Embrace Zero Single-Use Habit',
      action: 'Bring your own reusable tote bag, tumbler, and cutlery to cut daily plastic waste volume.',
      impact: 'Medium'
    });
    tips.push({
      title: 'Compost Organic Scraps',
      action: 'Separate food scraps from landfill waste to prevent anaerobic methane production.',
      impact: 'High'
    });
  }

  return tips;
}

/**
 * Simulate habit change ("What-If" simulator logic)
 */
function simulateHabitChange(currentMode, newMode, dailyKm) {
  const currentFactor = VEHICLE_FACTORS[currentMode] !== undefined ? VEHICLE_FACTORS[currentMode] : 0.192;
  const newFactor = VEHICLE_FACTORS[newMode] !== undefined ? VEHICLE_FACTORS[newMode] : 0.075;
  const km = parseFloat(dailyKm) || 20;

  const currentKg = Number((km * currentFactor).toFixed(2));
  const newKg = Number((km * newFactor).toFixed(2));
  const diffKg = Number((currentKg - newKg).toFixed(2));
  const annualDiffKg = Number((diffKg * 365).toFixed(0));
  const treesEquivalent = Math.max(1, Math.round(Math.abs(annualDiffKg) / 21));

  return {
    currentKg,
    newKg,
    diffKg,
    annualDiffKg,
    treesEquivalent,
    isReduction: diffKg > 0
  };
}

module.exports = {
  calculateFootprint,
  simulateHabitChange,
  VEHICLE_FACTORS,
  FUEL_FACTORS,
  DIET_FACTORS
};
