const User = require('../models/User');
const { getDbStatus } = require('../config/db');

// In-memory fallback user store if MongoDB is offline
let memoryUser = {
  _id: 'default_user',
  name: 'Eco Warrior',
  level: 4,
  levelTitle: 'Green Guardian',
  avatar: '🌱',
  joinedDate: 'Feb 2026',
  metrics: {
    todayFootprint: 4.2,
    previousFootprint: 4.8,
    ecoScore: 78,
    scoreBreakdown: {
      transport: 82,
      energy: 71,
      food: 76,
      waste: 85
    },
    streak: 7,
    streakDays: [
      { day: 'Mon', completed: true, date: '2026-09-16' },
      { day: 'Tue', completed: true, date: '2026-09-17' },
      { day: 'Wed', completed: true, date: '2026-09-18' },
      { day: 'Thu', completed: true, date: '2026-09-19' },
      { day: 'Fri', completed: true, date: '2026-09-20' },
      { day: 'Sat', completed: true, date: '2026-09-21' },
      { day: 'Sun', completed: true, date: '2026-09-22', isToday: true }
    ],
    ecoPoints: 450,
    pointsToNextLevel: 600,
    monthlyGoal: {
      budgetKg: 50.0,
      currentKg: 40.0,
      percentage: 80
    }
  }
};

/**
 * POST /api/users
 * Create a new user profile
 */
async function createUser(req, res, next) {
  try {
    const { name, email, avatar, level, levelTitle, metrics } = req.body;

    if (getDbStatus().connected) {
      const newUser = await User.create({
        name: name || 'Eco Warrior',
        email,
        avatar: avatar || '🌱',
        level: level || 4,
        levelTitle: levelTitle || 'Green Guardian',
        metrics: metrics || memoryUser.metrics
      });

      return res.status(201).json({
        success: true,
        data: newUser,
        source: 'mongodb'
      });
    }

    // In-memory fallback
    const id = 'user_' + Date.now();
    const newUser = {
      _id: id,
      name: name || 'Eco Warrior',
      email: email || '',
      avatar: avatar || '🌱',
      level: level || 4,
      levelTitle: levelTitle || 'Green Guardian',
      joinedDate: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
      metrics: metrics || memoryUser.metrics
    };
    memoryUser = newUser;

    return res.status(201).json({
      success: true,
      data: newUser,
      source: 'memory'
    });
  } catch (error) {
    next(error);
  }
}

/**
 * GET /api/users/:id
 * Retrieve user by ID
 */
async function getUserById(req, res, next) {
  try {
    const { id } = req.params;

    if (getDbStatus().connected && id !== 'default_user' && id !== 'me') {
      try {
        const user = await User.findById(id);
        if (user) {
          return res.status(200).json({ success: true, data: user, source: 'mongodb' });
        }
      } catch (err) {
        // Continue to fallback if not a valid ObjectId
      }
    }

    // If connected, try to find default or create one
    if (getDbStatus().connected) {
      let defaultUser = await User.findOne({ name: 'Eco Warrior' });
      if (!defaultUser) {
        defaultUser = await User.create(memoryUser);
      }
      return res.status(200).json({ success: true, data: defaultUser, source: 'mongodb' });
    }

    // In-memory fallback
    return res.status(200).json({
      success: true,
      data: memoryUser,
      source: 'memory'
    });
  } catch (error) {
    next(error);
  }
}

/**
 * PUT /api/users/:id
 * Update user profile & metrics
 */
async function updateUser(req, res, next) {
  try {
    const { id } = req.params;
    const updates = req.body;

    if (getDbStatus().connected && id !== 'default_user' && id !== 'me') {
      try {
        const updated = await User.findByIdAndUpdate(id, { $set: updates }, { new: true, runValidators: true });
        if (updated) {
          return res.status(200).json({ success: true, data: updated, source: 'mongodb' });
        }
      } catch (err) {
        // Fallback below
      }
    }

    if (getDbStatus().connected) {
      let defaultUser = await User.findOneAndUpdate(
        { name: 'Eco Warrior' },
        { $set: updates },
        { new: true, upsert: true }
      );
      return res.status(200).json({ success: true, data: defaultUser, source: 'mongodb' });
    }

    // In-memory fallback
    if (updates.name) memoryUser.name = updates.name;
    if (updates.avatar) memoryUser.avatar = updates.avatar;
    if (updates.level) memoryUser.level = updates.level;
    if (updates.levelTitle) memoryUser.levelTitle = updates.levelTitle;
    if (updates.metrics) {
      memoryUser.metrics = { ...memoryUser.metrics, ...updates.metrics };
    }

    return res.status(200).json({
      success: true,
      data: memoryUser,
      source: 'memory'
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  createUser,
  getUserById,
  updateUser,
  getMemoryUser: () => memoryUser
};
