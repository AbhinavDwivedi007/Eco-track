const { calculateFootprint, simulateHabitChange } = require('../services/carbonCalculator');
const CarbonCalculation = require('../models/CarbonCalculation');
const User = require('../models/User');
const { getDbStatus } = require('../config/db');
const { memoryHistory } = require('./historyController');
const { memoryUsers } = require('./authController');

/**
 * Helper to update user's streak and 7/14/30-day streak rewards
 */
function updateUserStreakAndRewards(user, footprintResult) {
  const today = new Date().toISOString().split('T')[0];
  const yesterdayDate = new Date();
  yesterdayDate.setDate(yesterdayDate.getDate() - 1);
  const yesterday = yesterdayDate.toISOString().split('T')[0];

  if (!user.streak) {
    user.streak = { current: 0, best: 0, lastTrackedDate: null, trackingDates: [] };
  }

  // Check consecutive days
  if (user.streak.lastTrackedDate === today) {
    // Already tracked today - maintain streak, ensure date is in array
    if (!user.streak.trackingDates.includes(today)) {
      user.streak.trackingDates.push(today);
    }
  } else if (user.streak.lastTrackedDate === yesterday) {
    // Consecutive day tracking!
    user.streak.current = (user.streak.current || 0) + 1;
    user.streak.best = Math.max(user.streak.best || 0, user.streak.current);
    user.streak.lastTrackedDate = today;
    if (!user.streak.trackingDates.includes(today)) {
      user.streak.trackingDates.push(today);
    }
  } else {
    // First time or missed day(s) -> streak resets to 1
    user.streak.current = 1;
    user.streak.best = Math.max(user.streak.best || 1, 1);
    user.streak.lastTrackedDate = today;
    if (!user.streak.trackingDates.includes(today)) {
      user.streak.trackingDates.push(today);
    }
  }

  // Update metrics
  if (!user.metrics) user.metrics = {};
  user.metrics.previousFootprint = user.metrics.todayFootprint || footprintResult.totalFootprintKg;
  user.metrics.todayFootprint = footprintResult.totalFootprintKg;
  user.metrics.ecoScore = footprintResult.ecoScore;
  user.metrics.ecoGrade = footprintResult.ecoGrade;
  user.metrics.highestCategory = footprintResult.highestContributor?.key || 'transport';
  user.metrics.scoreBreakdown = footprintResult.breakdown;
  user.metrics.totalCalculations = (user.metrics.totalCalculations || 0) + 1;

  // Check 7, 14, 30 day Eco Streak Rewards
  // Rule: Once earned, stays earned even if current streak later resets!
  const effectiveStreak = Math.max(user.streak.current, user.streak.best);

  if (Array.isArray(user.rewards)) {
    user.rewards.forEach(reward => {
      if (!reward.unlocked && effectiveStreak >= reward.daysRequired) {
        reward.unlocked = true;
        reward.unlockedAt = new Date();
      }
    });
  }

  return user;
}

/**
 * POST /api/carbon/calculate
 * Calculate carbon footprint from parameters and link to user
 */
async function calculate(req, res, next) {
  try {
    const input = req.body;
    const result = calculateFootprint(input);

    let saved = false;
    let calculationId = null;
    let updatedUser = null;

    // Identify user if authenticated or provided
    const userId = req.user ? req.user._id.toString() : (input.userId || 'default_user');

    if (input.saveToHistory !== false) {
      if (getDbStatus().connected) {
        const record = await CarbonCalculation.create({
          userId,
          inputs: input,
          results: result,
          source: 'calculator'
        });
        saved = true;
        calculationId = record._id;

        // Update user streak & metrics if authenticated or user exists
        if (req.user) {
          let user = await User.findById(req.user._id);
          if (user) {
            updateUserStreakAndRewards(user, result);
            await user.save();
            updatedUser = {
              _id: user._id,
              name: user.name,
              email: user.email,
              metrics: user.metrics,
              streak: user.streak,
              rewards: user.rewards
            };
          }
        }
      } else {
        // In-memory fallback
        const memoryRecord = {
          _id: 'calc_' + Date.now(),
          userId,
          inputs: input,
          results: result,
          source: 'calculator',
          createdAt: new Date()
        };
        memoryHistory.unshift(memoryRecord);
        saved = true;
        calculationId = memoryRecord._id;

        // If authenticated memory user exists
        if (req.user && memoryUsers) {
          const memUser = Array.from(memoryUsers.values()).find(u => u._id === req.user._id);
          if (memUser) {
            updateUserStreakAndRewards(memUser, result);
            updatedUser = {
              _id: memUser._id,
              name: memUser.name,
              email: memUser.email,
              metrics: memUser.metrics,
              streak: memUser.streak,
              rewards: memUser.rewards
            };
          }
        }

        // Persist memory changes to local storage file
        try {
          const { savePersistedData } = require('../config/localStorage');
          savePersistedData(memoryUsers, memoryHistory);
        } catch (e) {
          // ignore
        }
      }
    }

    return res.status(200).json({
      success: true,
      data: {
        ...result,
        saved,
        calculationId,
        user: updatedUser
      }
    });
  } catch (error) {
    next(error);
  }
}

/**
 * POST /api/carbon/simulate
 * "What If?" Habit change scenario simulation
 */
async function simulate(req, res, next) {
  try {
    const { currentMode = 'car', newMode = 'bus', dailyKm = 20 } = req.body;
    const result = simulateHabitChange(currentMode, newMode, dailyKm);

    return res.status(200).json({
      success: true,
      data: result
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  calculate,
  simulate,
  updateUserStreakAndRewards
};
