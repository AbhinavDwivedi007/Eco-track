const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const { RewardMilestones } = require('../models/User');
const { getDbStatus } = require('../config/db');
const { JWT_SECRET } = require('../middleware/auth');

const { loadPersistedData, savePersistedData } = require('../config/localStorage');

// In-memory users map for fallback mode when MongoDB is offline
const memoryUsers = new Map();

// Initialize memory users from persistent disk cache if available
const persisted = loadPersistedData();
if (persisted.users && persisted.users.length > 0) {
  persisted.users.forEach(u => {
    if (u && u.email) {
      memoryUsers.set(u.email.toLowerCase().trim(), u);
    }
  });
}

// Helper to save current in-memory state
function persistState() {
  try {
    const historyController = require('./historyController');
    savePersistedData(memoryUsers, historyController.memoryHistory);
  } catch (e) {
    // ignore
  }
}

// Helper to sign JWT token
function generateToken(id, name, email) {
  return jwt.sign({ id, name, email }, JWT_SECRET, { expiresIn: '30d' });
}

// Helper to create clean user response
function formatUserResponse(user) {
  return {
    _id: user._id,
    name: user.name,
    email: user.email,
    avatar: user.avatar,
    joinedDate: user.joinedDate,
    metrics: user.metrics,
    streak: user.streak,
    rewards: user.rewards
  };
}

/**
 * POST /api/auth/register
 * Register a new user
 */
async function register(req, res, next) {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide name, email, and password'
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long'
      });
    }

    const normalizedEmail = email.toLowerCase().trim();

    if (getDbStatus().connected) {
      const userExists = await User.findOne({ email: normalizedEmail });
      if (userExists) {
        return res.status(400).json({
          success: false,
          message: 'An account with this email already exists'
        });
      }

      const user = await User.create({
        name: name.trim(),
        email: normalizedEmail,
        password
      });

      const token = generateToken(user._id, user.name, user.email);

      return res.status(201).json({
        success: true,
        message: 'Account created successfully',
        token,
        user: formatUserResponse(user)
      });
    }

    // In-memory fallback
    if (memoryUsers.has(normalizedEmail)) {
      return res.status(400).json({
        success: false,
        message: 'An account with this email already exists'
      });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const memUser = {
      _id: 'user_' + Date.now(),
      name: name.trim(),
      email: normalizedEmail,
      password: hashedPassword,
      avatar: '🌱',
      joinedDate: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      metrics: {
        todayFootprint: 0,
        previousFootprint: 0,
        ecoScore: 75,
        ecoGrade: 'B',
        highestCategory: 'transport',
        scoreBreakdown: { transport: 0, energy: 0, food: 0, waste: 0 },
        totalCalculations: 0
      },
      streak: {
        current: 0,
        best: 0,
        lastTrackedDate: null,
        trackingDates: []
      },
      rewards: RewardMilestones.map(m => ({ ...m, unlocked: false, unlockedAt: null }))
    };

    memoryUsers.set(normalizedEmail, memUser);
    persistState();
    const token = generateToken(memUser._id, memUser.name, memUser.email);

    return res.status(201).json({
      success: true,
      message: 'Account created successfully',
      token,
      user: formatUserResponse(memUser)
    });
  } catch (error) {
    next(error);
  }
}

/**
 * POST /api/auth/login
 * Authenticate existing user
 */
async function login(req, res, next) {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide both email and password'
      });
    }

    const normalizedEmail = email.toLowerCase().trim();

    if (getDbStatus().connected) {
      const user = await User.findOne({ email: normalizedEmail }).select('+password');
      if (!user) {
        return res.status(401).json({
          success: false,
          message: 'Invalid email or password'
        });
      }

      const isMatch = await user.matchPassword(password);
      if (!isMatch) {
        return res.status(401).json({
          success: false,
          message: 'Invalid email or password'
        });
      }

      const token = generateToken(user._id, user.name, user.email);

      return res.status(200).json({
        success: true,
        message: 'Login successful',
        token,
        user: formatUserResponse(user)
      });
    }

    // In-memory fallback
    const memUser = memoryUsers.get(normalizedEmail);
    if (!memUser) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }

    const isMatch = await bcrypt.compare(password, memUser.password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }

    const token = generateToken(memUser._id, memUser.name, memUser.email);

    return res.status(200).json({
      success: true,
      message: 'Login successful',
      token,
      user: formatUserResponse(memUser)
    });
  } catch (error) {
    next(error);
  }
}

/**
 * GET /api/auth/me
 * Get current authenticated user profile
 */
async function getMe(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Not authenticated' });
    }

    if (getDbStatus().connected) {
      const user = await User.findById(req.user._id);
      if (!user) {
        return res.status(404).json({ success: false, message: 'User not found' });
      }
      return res.status(200).json({
        success: true,
        user: formatUserResponse(user)
      });
    }

    // In-memory
    const memUser = Array.from(memoryUsers.values()).find(u => u._id === req.user._id) || req.user;
    return res.status(200).json({
      success: true,
      user: formatUserResponse(memUser)
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  register,
  login,
  getMe,
  memoryUsers
};
