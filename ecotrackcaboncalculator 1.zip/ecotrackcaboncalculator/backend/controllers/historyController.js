const CarbonCalculation = require('../models/CarbonCalculation');
const { getDbStatus } = require('../config/db');
const { loadPersistedData, savePersistedData } = require('../config/localStorage');

// In-memory fallback history store
let memoryHistory = [];

// Initialize memoryHistory from persisted storage if available
const persisted = loadPersistedData();
if (persisted.history && Array.isArray(persisted.history)) {
  memoryHistory.push(...persisted.history);
}

// Helper to persist history changes to disk
function persistHistoryState() {
  try {
    const { memoryUsers } = require('./authController');
    savePersistedData(memoryUsers, memoryHistory);
  } catch (err) {
    // ignore
  }
}

/**
 * POST /api/carbon/history
 * Save a carbon calculation record to history
 */
async function saveHistory(req, res, next) {
  try {
    const userId = req.user ? req.user._id.toString() : (req.body.userId || 'default_user');
    const { inputs, results, source = 'calculator' } = req.body;

    if (!results || results.totalFootprintKg === undefined) {
      return res.status(400).json({
        success: false,
        message: 'Calculation results are required to save to history'
      });
    }

    if (getDbStatus().connected) {
      const calculation = await CarbonCalculation.create({
        userId,
        inputs: inputs || {},
        results,
        source
      });

      return res.status(201).json({
        success: true,
        data: calculation,
        source: 'mongodb'
      });
    }

    // In-memory fallback
    const newRecord = {
      _id: 'calc_' + Date.now(),
      userId,
      inputs: inputs || {},
      results,
      source,
      createdAt: new Date()
    };
    memoryHistory.unshift(newRecord);
    persistHistoryState();

    return res.status(201).json({
      success: true,
      data: newRecord,
      source: 'memory'
    });
  } catch (error) {
    next(error);
  }
}

/**
 * GET /api/carbon/history
 * Retrieve calculation history for the current user
 */
async function getHistory(req, res, next) {
  try {
    const limit = parseInt(req.query.limit) || 20;
    const userId = req.user ? req.user._id.toString() : (req.query.userId || 'default_user');

    if (getDbStatus().connected) {
      // Find calculations specifically for this user
      const query = req.user ? { userId } : {};
      const calcs = await CarbonCalculation.find(query).sort({ createdAt: -1 }).limit(limit).lean();

      return res.status(200).json({
        success: true,
        data: {
          calculations: calcs
        },
        source: 'mongodb'
      });
    }

    // In-memory fallback
    const filtered = req.user
      ? memoryHistory.filter(h => h.userId === userId)
      : memoryHistory;

    return res.status(200).json({
      success: true,
      data: {
        calculations: filtered.slice(0, limit)
      },
      source: 'memory'
    });
  } catch (error) {
    next(error);
  }
}

/**
 * GET /api/carbon/history/:id
 * Retrieve specific history item by ID
 */
async function getHistoryById(req, res, next) {
  try {
    const { id } = req.params;

    if (getDbStatus().connected) {
      try {
        const item = await CarbonCalculation.findById(id);
        if (item) {
          return res.status(200).json({ success: true, data: item, source: 'mongodb' });
        }
      } catch (e) {
        // Fall through
      }
    }

    const found = memoryHistory.find(h => h._id === id);
    if (!found) {
      return res.status(404).json({ success: false, message: 'History record not found' });
    }

    return res.status(200).json({ success: true, data: found, source: 'memory' });
  } catch (error) {
    next(error);
  }
}

/**
 * DELETE /api/carbon/history/:id
 * Delete a history record
 */
async function deleteHistory(req, res, next) {
  try {
    const { id } = req.params;

    if (getDbStatus().connected) {
      try {
        const deleted = await CarbonCalculation.findByIdAndDelete(id);
        if (deleted) {
          return res.status(200).json({ success: true, message: 'Calculation deleted', source: 'mongodb' });
        }
      } catch (e) {
        // Fall through
      }
    }

    const index = memoryHistory.findIndex(h => h._id === id);
    if (index !== -1) {
      memoryHistory.splice(index, 1);
      persistHistoryState();
      return res.status(200).json({ success: true, message: 'Calculation deleted', source: 'memory' });
    }

    return res.status(404).json({ success: false, message: 'Record not found' });
  } catch (error) {
    next(error);
  }
}

/**
 * GET /api/carbon/history/summary
 * Real monthly & analytics summary for charts and progress reporting
 */
async function getSummary(req, res, next) {
  try {
    const userId = req.user ? req.user._id.toString() : (req.query.userId || 'default_user');

    let calcs = [];
    if (getDbStatus().connected) {
      const query = req.user ? { userId } : {};
      calcs = await CarbonCalculation.find(query).sort({ createdAt: -1 }).limit(30).lean();
    } else {
      calcs = req.user
        ? memoryHistory.filter(h => h.userId === userId)
        : memoryHistory;
    }

    const now = new Date();
    const currentMonthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    const prevDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const prevMonthKey = `${prevDate.getFullYear()}-${String(prevDate.getMonth() + 1).padStart(2, '0')}`;

    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const currentMonthName = `${monthNames[now.getMonth()]} ${now.getFullYear()}`;
    const prevMonthName = `${monthNames[prevDate.getMonth()]} ${prevDate.getFullYear()}`;

    // If user has calculations, compute real analytics
    if (calcs.length > 0) {
      const totalFootprintSum = calcs.reduce((acc, c) => acc + (c.results?.totalFootprintKg || 0), 0);
      const avgFootprint = Number((totalFootprintSum / calcs.length).toFixed(1));

      // Category breakdown aggregation
      let tSum = 0, eSum = 0, fSum = 0, wSum = 0;
      calcs.forEach(c => {
        const bd = c.results?.breakdown || {};
        tSum += bd.transport || 0;
        eSum += bd.electricity || 0;
        fSum += bd.food || 0;
        wSum += bd.waste || 0;
      });
      const grandTotal = (tSum + eSum + fSum + wSum) || 1;

      const categoryDistribution = [
        { label: 'Transport', percent: Math.round((tSum / grandTotal) * 100), color: '#10b981' },
        { label: 'Energy', percent: Math.round((eSum / grandTotal) * 100), color: '#0284c7' },
        { label: 'Food', percent: Math.round((fSum / grandTotal) * 100), color: '#16a34a' },
        { label: 'Waste', percent: Math.round((wSum / grandTotal) * 100), color: '#64748b' }
      ];

      // Recent 7 calculation entries for trend
      const recentCalcs = calcs.slice(0, 7).reverse();
      const weeklyTrend = recentCalcs.map(c => {
        const d = new Date(c.createdAt);
        const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
        return {
          day: dayName,
          date: d.toISOString().split('T')[0],
          footprint: c.results?.totalFootprintKg || 0,
          target: 4.0
        };
      });

      // Monthly breakdown
      const currentMonthCalcs = calcs.filter(c => {
        const dStr = (c.createdAt ? new Date(c.createdAt) : now).toISOString();
        return dStr.startsWith(currentMonthKey);
      });

      const prevMonthCalcs = calcs.filter(c => {
        const dStr = (c.createdAt ? new Date(c.createdAt) : now).toISOString();
        return dStr.startsWith(prevMonthKey);
      });

      const curSum = currentMonthCalcs.reduce((acc, c) => acc + (c.results?.totalFootprintKg || 0), 0);
      const curAvg = currentMonthCalcs.length > 0 ? Number((curSum / currentMonthCalcs.length).toFixed(1)) : avgFootprint;

      const prevSum = prevMonthCalcs.reduce((acc, c) => acc + (c.results?.totalFootprintKg || 0), 0);
      const prevAvg = prevMonthCalcs.length > 0 ? Number((prevSum / prevMonthCalcs.length).toFixed(1)) : 0;

      let diffKg = 0;
      let percentReduction = 0;
      let isImprovement = true;

      if (prevMonthCalcs.length > 0 && prevAvg > 0) {
        diffKg = Number((prevAvg - curAvg).toFixed(1));
        percentReduction = Number(((diffKg / prevAvg) * 100).toFixed(1));
        isImprovement = diffKg >= 0;
      } else if (calcs.length >= 2) {
        const latestVal = calcs[0].results?.totalFootprintKg || 0;
        const previousVal = calcs[1].results?.totalFootprintKg || latestVal;
        diffKg = Number((previousVal - latestVal).toFixed(1));
        percentReduction = previousVal > 0 ? Number(((diffKg / previousVal) * 100).toFixed(1)) : 0;
        isImprovement = diffKg >= 0;
      } else {
        // First entry - compare to target of 4.0kg
        diffKg = Number((4.0 - curAvg).toFixed(1));
        percentReduction = Number(((diffKg / 4.0) * 100).toFixed(1));
        isImprovement = curAvg <= 4.0;
      }

      const monthlyProgress = {
        currentMonth: {
          name: currentMonthName,
          count: currentMonthCalcs.length,
          avgFootprint: curAvg,
          totalFootprint: Number(curSum.toFixed(1))
        },
        previousMonth: {
          name: prevMonthName,
          count: prevMonthCalcs.length,
          avgFootprint: prevAvg,
          totalFootprint: Number(prevSum.toFixed(1))
        },
        comparison: {
          diffKg: Math.abs(diffKg),
          percentReduction: Math.abs(percentReduction),
          isImprovement,
          text: isImprovement
            ? `${Math.abs(percentReduction)}% lower than reference period`
            : `${Math.abs(percentReduction)}% higher than reference period`
        }
      };

      return res.status(200).json({
        success: true,
        data: {
          hasData: true,
          totalCalculations: calcs.length,
          avgFootprint,
          latestFootprint: calcs[0].results?.totalFootprintKg || 0,
          latestEcoScore: calcs[0].results?.ecoScore || 75,
          weeklyTrend,
          categoryDistribution,
          monthlyProgress
        }
      });
    }

    // Default clean initial state for fresh user
    const defaultMonthlyProgress = {
      currentMonth: {
        name: currentMonthName,
        count: 0,
        avgFootprint: 0,
        totalFootprint: 0
      },
      previousMonth: {
        name: prevMonthName,
        count: 0,
        avgFootprint: 0,
        totalFootprint: 0
      },
      comparison: {
        diffKg: 0,
        percentReduction: 0,
        isImprovement: true,
        text: 'No calculations logged yet'
      }
    };

    return res.status(200).json({
      success: true,
      data: {
        hasData: false,
        totalCalculations: 0,
        avgFootprint: 0,
        latestFootprint: 0,
        latestEcoScore: 75,
        weeklyTrend: [],
        categoryDistribution: [
          { label: 'Transport', percent: 25, color: '#10b981' },
          { label: 'Energy', percent: 25, color: '#0284c7' },
          { label: 'Food', percent: 25, color: '#16a34a' },
          { label: 'Waste', percent: 25, color: '#64748b' }
        ],
        monthlyProgress: defaultMonthlyProgress
      }
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  saveHistory,
  getHistory,
  getHistoryById,
  deleteHistory,
  getSummary,
  memoryHistory
};
